# P5 实施交付记录（2026-11-22）

> 当前功能描述已按 2026-11-26 的四组协议更新。下方日期对应的测试次数仅是历史执行记录。

结论：P5 已获用户正式授权并已完成本轮主要实验工具链实现；**尚未通过完整 P5 验收**。本机辅助验证不能代替 Linux/RTX 4090 多种子实验，也不能补齐尚不存在的原系统参照。任务、步骤、命令和完整门槛见 [P5 README](README.md)，机器协议见 [当前协议](protocol.json)。

## 实现内容与文件

| 文件 | 用途 |
|---|---|
| `src/sac_rwb/algos/p5_models.py` | 独立四组工厂：复用 B0/M1，增加 A-B、零风险 S0 |
| `src/sac_rwb/algos/p5_experiment.py` | 固定预算离线 BCE 优化、共用数据指纹、掩码输入、validation-only 校准、冻结测试预测、训练后推理成本、配对训练种子汇总、UNC 逐层建目录 |
| `src/sac_rwb/algos/p5_metrics.py` | 网络级 SUMO 碰撞车辆对起点、出发/到达/碰撞车辆分母、队列/等待/速度逐步物理日志及重审 |
| `src/sac_rwb/Env.py` | 仅新增默认关闭的 `physical_observer` 回调；包含 reset/空闲步，未配置时保留旧路径 |
| `scripts/p5_worker.py` | 从头在线共享 SAC+H=10 风险训练、固定末点权重、独立离线拟合、固定仿真时长冻结评价；重置随机种子保证各组 SAC 初始 actor 配对 |
| `scripts/accept_p5.py` | local/smoke/research 分层入口、锁定环境/协议、共同 P4 B0 强化审计与冻结指纹、完整执行矩阵、源码快照、进程组超时终止、命令日志/退出码 |
| `scripts/audit_p5.py` | 完整矩阵与预算核对、检查点/数据/预测/标签重算、物理日志重算、自然优化与系统参照缺失门控、配对差值/均值/标准差/描述性区间 |
| `scripts/package_p5.py` | 活跃源码和文档交付包，逐成员哈希验证；不含原始参考资料及历史运行数据 |
| `scripts/export_p5.py` | 回传环境、日志、源码、模型、预测和物理流；大型在线/共用原始数据继续保留服务器 |
| `scripts/verify_p01234.py`、`tests/test_verify_p01234.py` | 仅识别 Env 中精确匹配的可选 P5 回调，仍拒绝其他未审核运行逻辑差异；验证默认兼容 |
| `tests/test_p5.py`、`tests/test_p5_worker.py` | 新模型、真实 CPU 梯度/优化、掩码/动作路径、保存加载、校准隔离、物理分母、缺失证据、完整替代仿真链路与 smoke 不得授予研究验收 |
| `.gitignore` | 在线大型 JSONL 与回传包不进入 Git |
| 根/工作副本 README、实施规范、`plan/stage-gates.md`、`plan/progress.md`、`plan/experiment-protocol.md`、`plan/p5/` | 更新授权、任务、当前状态、协议和操作说明；历史验收文件保持历史事实 |

未改动旧 `train_sac.py`、旧 B0/M1 工厂、SAC 算法、P4 标签及数据指标公式。未删除实验数据、参考快照、检查点或章节；章节 3.4 保持保护。P0–P4 的通过仍限于原有门槛，不自动授予新增 P5 目标代码验收。

## 协议与验收口径

三组风险器使用同一冻结 P4 B0 语料（包含已经接受的 train 扩展），种子 11/23/37，各 5,000 次平衡 batch=128 更新。四组在线策略各 100,000 个决策步；3 个测试种子、3 种 flow 密度、每次 3,600 个完整仿真步，共 108 次闭环评价。模型固定末预算，校准只使用 validation，测试不选择权重；离线与在线模型分别从头训练。


只有目标环境零跳过回归、完整公平矩阵、所有非 S0 自然风险器实际更新、原系统参照及可重算的指标均满足时，才允许 P5 `passed=true`。效果不优于 B0 或消融是可接受研究结果，不能据此重选种子。三种子及最低事件支持量不等于统计功效充分。

## 实际验证记录

执行 `python -B scripts/accept_p5.py --local`。首轮集成暴露 Windows/WSL UNC 深层目录创建问题，已修复为逐层创建；失败证据 [20261122T091531727475Z](runs/20261122T091531727475Z/summary.json) 保留。

修复后完整本机回归 [20261122T092014428044Z](runs/20261122T092014428044Z/summary.json)：106 项，102 通过、4 CUDA 跳过，0 失败/错误；unit/static 均退出 0，`local_checks_passed=true`，`passed=false`。新增 CUDA 测试要求保留的消融各做真实 GPU 更新，本机不能执行；目标模式禁止这些跳过。

最后修订系统参照接口说明后，再次完整验证：[最终运行](runs/20261122T092249404846Z/summary.json) 退出 0，unit/static 均退出 0，运行期间源码未变；[最终测试](runs/20261122T092249404846Z/unit-results.json) 仍为 106 项、102 通过、4 CUDA 跳过、0 失败/错误。结果为 `auxiliary_passed_not_p5_acceptance`，没有授予目标 P5 验收。

独立调用 `historical_proof(False)`、`structural_proof()` 已实际通过：[默认兼容及结构报告](legacy-compatibility-20261122.json)。验证默认 Env 语义、既有目标日志、冻结检查点/评估元数据、活跃依赖、SUMO 输入及恢复包；本机不冒充重新读取服务器原始 JSONL。活跃 Python 文件也已按 Python 3.7 语法解析通过；真实 Python 3.7/PyTorch 1.13/CUDA/SUMO 联调仍由服务器执行。

`test_p5_worker` 使用替代 Env/SAC，覆盖三组 60 决策训练调用、30 仿真步冻结评价、离线两次真实 CPU 优化及完整 smoke 审计，明确为 synthetic fixture。它不代表真实 SAC 已收敛、SUMO 已运行或风险学习改善。模型专项实际 CPU 更新、掩码/梯度及保存加载测试均已执行。

## 遗留问题和下一步

1. 用户按 [README 的上传、smoke 与正式运行步骤](README.md) 在原服务器执行，回传 `export_p5.py` 生成的包及 SHA-256。这里没有擅自连接或在远端启动任务。
2. 缺少 PPO、FCFS、混合交通原方法的完整可复现实现及配置。已向用户询问其路径/仓库；没有临时拼凑替代方法。已提供源程序/技术评审/共同物理流的导入审计契约，缺失时完整 P5 保持未通过。
3. 目标训练可能仍无足够自然正例而出现零风险优化；程序会如实保留计数并返回不足，不伪造碰撞、不降低 P4 门槛。smoke 的零自然优化不作为研究通过证据。
4. 正式在线日志可能很大，应先用 smoke 观测增长并核对磁盘。无 optimizer/replay 完整续训，不从半程模型冒充从头训练预算。
5. 评价 AQL/AWT 是环境组均值，速度是车辆时间均值；固定时长内未到达车辆保留计数，不能把这些指标写成完整行程旅行时间或零风险证明。P4 test 已用于工程诊断的历史使用范围继续披露。

## 能力使用记录

读取 using-research-writing 路由、experiment-results-planning 和 verification；实际用于锁定对照、指标、数据/消融归因边界及测试后才声明状态。消费既有方案、协议、P0–P4 验收、源码和测试；查阅 SUMO 官方 getCollisions 接口并在 README 标注来源。未改写论文、未生成虚拟研究结果、未新建论文图表，因此不启动章节写作/文献综述/出版图表流程。产物为上述代码、协议、文档、测试和交付工具；剩余研究证据见遗留问题。
